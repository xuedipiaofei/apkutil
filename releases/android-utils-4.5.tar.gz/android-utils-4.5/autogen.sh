#!/bin/sh
pushd libpng-1.2.51
./autogen.sh
popd

libtoolize -c -i
aclocal
autoconf
automake -a -c
