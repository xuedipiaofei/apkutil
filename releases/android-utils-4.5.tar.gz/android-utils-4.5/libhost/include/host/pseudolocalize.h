#ifndef HOST_PSEUDOLOCALIZE_H
#define HOST_PSEUDOLOCALIZE_H

#include <string>

std::string pseudolocalize_string(const std::string& source);

#endif // HOST_PSEUDOLOCALIZE_H

